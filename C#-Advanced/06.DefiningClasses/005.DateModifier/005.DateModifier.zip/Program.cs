﻿using _005.DateModifier;

string start = Console.ReadLine();
string end = Console.ReadLine();    


Console.WriteLine(DateModifier.GetDifferenceInDays(start,end));

