﻿using CostumLinkedList;

SoftUniLinkedList<string> list = new ();
list.AddLast("hjdsds");