﻿namespace Horizons.Models
{
    public class EditViewModel : DestinationInputModel
    {
        public int Id { get; set; }
    }
}
