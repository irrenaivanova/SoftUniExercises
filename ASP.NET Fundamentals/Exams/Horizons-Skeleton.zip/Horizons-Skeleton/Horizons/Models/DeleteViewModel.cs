﻿namespace Horizons.Models
{
    public class DeleteViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Publisher { get; set; }

        public string PublisherId { get; set; }
    }
}
