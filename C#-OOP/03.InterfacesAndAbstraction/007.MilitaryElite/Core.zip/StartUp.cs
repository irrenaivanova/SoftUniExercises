﻿using _007.MilitaryElite.Core;
using _007.MilitaryElite.Models;

Engine engine = new();
engine.Run();