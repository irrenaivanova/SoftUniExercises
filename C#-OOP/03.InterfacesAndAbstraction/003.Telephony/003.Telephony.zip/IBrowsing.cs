﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _003.Telephony
{
    public interface IBrowsing
    {
        public void Browsing(string web);

    }
}
