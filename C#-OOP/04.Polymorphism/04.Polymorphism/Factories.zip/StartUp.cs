﻿using _04.Polymorphism.Core;
using _04.Polymorphism.Factories;
using _04.Polymorphism.IO;

Engine engine = new Engine(new ConsoleReader(), new ConsoleWriter(), new VehicleFactory());
engine.Run();