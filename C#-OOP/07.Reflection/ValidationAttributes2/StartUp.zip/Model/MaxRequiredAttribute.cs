﻿namespace ValidationAttributes2.Model
{
    internal class MaxRequiredAttribute : Attribute
    {
    }
}