﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _005.FootballTeamGenerator
{
    public static class ExceptionsMessage
    {
        public const string StatsException = "{0} should be between {1} and {2}.";
    }
}
