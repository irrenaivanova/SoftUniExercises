﻿
using P02_FootballBetting.Data;

var db = new FootballBettingContext();

db.Database.EnsureCreated();