﻿namespace P02_FootballBetting.Data.Common
{
    public static class LengthRestrictions
    {
        public const int lengthRestrictionName = 50;
        public const int TeamNameMaxLength = 50;
    }
}