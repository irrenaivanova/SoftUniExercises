﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_FootballBetting.Data.Common
{
    public static class Config
    {
        public const string ConnectionString = "Server =.; Database = FootballBetting4; Integrated Security = true; TrustServerCertificate = True";
    }
}
