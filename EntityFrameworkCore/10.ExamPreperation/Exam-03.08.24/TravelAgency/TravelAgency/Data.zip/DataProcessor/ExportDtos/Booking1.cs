﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TravelAgency.DataProcessor.ExportDtos
{
    public class Booking1
    {
        public string TourPackageName { get; set; }

        public string Date { get; set; }
    }
}
