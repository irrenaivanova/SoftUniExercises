﻿namespace VaporStore.DataProcessor
{
	using System;
    using System.Linq;
    using Data;
    using Newtonsoft.Json;
    using VaporStore.DataProcessor.Dto.Export;

    public static class Serializer
	{
		public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
		{
			var genres = context.Genres.ToList().Where(x => genreNames.Contains(x.Name))
				.Select(x => new GenreExport()
				{
					Id = x.Id,
					Genre = x.Name,
					Games = x.Games.Where(x=>x.Purchases.Count()>0).Select(x => new GameExport()
					{
						Id = x.Id,
						Title = x.Name,
						Developer = x.Developer.Name,
						Tags = string.Join(", ", x.GameTags.Select(x => x.Tag.Name)),
						Players = x.Purchases.Count()
					}).OrderByDescending(x => x.Players).ThenBy(x => x.Id).ToList(),

                    TotalPlayers = x.Games.Sum(x => x.Purchases.Count()),
                }).OrderByDescending(x => x.TotalPlayers).ThenBy(x => x.Id).ToList();
			return JsonConvert.SerializeObject(genres,Formatting.Indented);
		}

		public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
		{
			throw new NotImplementedException();
		}
	}
}